'use strict';

import vscode = require('vscode');

export const AUTOLISP_MODE: vscode.DocumentFilter = { language: 'autolisp', scheme: 'file' };